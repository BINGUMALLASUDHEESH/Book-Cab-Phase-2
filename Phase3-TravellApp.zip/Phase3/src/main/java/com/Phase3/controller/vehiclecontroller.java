package com.Phase3.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Phase3.bean.vehicles;
import com.Phase3.service.vehicleserviceimplements;

@Controller
public class vehiclecontroller {

	
	@Autowired
	vehicleserviceimplements vs;
	
	
	@GetMapping("/addvehicle")
	public String Addvehicle(Model m) {
		m.addAttribute("vehicle",new vehicles());
		return "addvehicle";
	}
	
	@PostMapping("addvehicledet")
	public String Addvehicle(Model m,@ModelAttribute("vehicle") vehicles veh) {
		
		String res=vs.addvehicle(veh);
		if(res.equalsIgnoreCase("success"))
			System.out.println("vehicle Added");
		return "redirect:/allvel";
	}
	
	
	@GetMapping("allvel")
	public String allvehicles(Model m) {
		List<vehicles> allvel=vs.viewallvehicles();
		m.addAttribute("allvel", allvel);
		return "allvehicles";
	}
	
	@PostMapping("/delveh")
	public String deletevehicle(@RequestParam("id") int id,Model m) {
		
		vs.deletevehicle(id);
		
		return "redirect:/allvel";
	}
	
	@PostMapping("/updveh")
	public String updatevehicle(@RequestParam("id") int id,Model m) {
		
		vehicles veh=vs.findbyid(id);
		m.addAttribute("vehicle", veh);
		
		return "updatevehicle";
	}
	
	@PostMapping("/updatevehicledetails")
	public String updatevehicle(@ModelAttribute("vehicle") vehicles ve,Model m) {
		
		String res =vs.update(ve);
		if(res.equalsIgnoreCase("success"))
			System.out.println("updated");
		return "redirect:/allvel";
	}
	
}
