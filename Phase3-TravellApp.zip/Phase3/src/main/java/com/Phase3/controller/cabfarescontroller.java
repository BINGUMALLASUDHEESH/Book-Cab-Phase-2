package com.Phase3.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller; 
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Phase3.bean.cabfares;
import com.Phase3.service.cabserviceimplements;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import aj.org.objectweb.asm.Type;


@Controller
public class cabfarescontroller {
	
	@Autowired
	cabserviceimplements cs;

	@GetMapping("")
	public String index(Model m) {
		
		return "index";
	}
	
	@GetMapping("/addcab")
	public String Addcab(Model m) {
		
		m.addAttribute("cab", new cabfares()); 
		return "cab";
	}
	
	@PostMapping("/addcabdet")
	public String Addcab(@ModelAttribute("cab") cabfares cf,Model m) {
		String res=cs.addcab(cf);
		if(res.equalsIgnoreCase("sucess")) {
			m.addAttribute("cab", new cabfares());
		}
		return "redirect:/allcabdet";
	}
	
	@GetMapping("/allcabdet")
	public String allcabs(Model m) {
		
		List<cabfares> allcab=cs.viewallcabs();
		m.addAttribute("allcabdetails", allcab);
		return "allcab";
	}
	
	@PostMapping("/del")
	public String delete(@RequestParam("id") int cid,Model m) {
		
		cs.deletecab(cid);
		return "redirect:/allcabdet";
	}
	
	@PostMapping("/update")
	public String update(@RequestParam("id") int cid, Model m) {
	    cabfares cab = cs.findbyid(cid);
	    if (cab != null) {
	        m.addAttribute("cab", cab);
	    }
	    return "updatecab";
	}

	@PostMapping("/upddet")
	public String update(@ModelAttribute("cab") cabfares cf,Model m) {
		
		String res=cs.update(cf);
		
		if(res.equalsIgnoreCase("success")) {
			System.out.println("updated");
		}
		return "redirect:/allcabdet";
	}
	
}
