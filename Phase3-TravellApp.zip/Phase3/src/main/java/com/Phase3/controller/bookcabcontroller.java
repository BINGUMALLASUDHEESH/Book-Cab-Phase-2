package com.Phase3.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Phase3.bean.bookcab;
import com.Phase3.bean.vehicles;
import com.Phase3.service.bookserviceimplements;
import com.Phase3.service.cabserviceimplements;
import com.Phase3.service.vehicleserviceimplements;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Controller
public class bookcabcontroller {

	@Autowired
	cabserviceimplements cs;
	@Autowired
	vehicleserviceimplements vs;
	@Autowired
	bookserviceimplements bs;
	
	@GetMapping("/addbook")
    public String bookingcab(Model m) {
        Map<String, List<String>> routeDictionary = cs.createroutedictionary();
       // System.out.println(routeDictionary.size());
       // System.out.println(Type(routeDictionary));
 
        ObjectMapper objectMapper = new ObjectMapper();
        String routeDictionaryJson;
        try {
            routeDictionaryJson = objectMapper.writeValueAsString(routeDictionary);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            routeDictionaryJson = "{}"; // Provide a default value in case of error
        }
        
        List<vehicles> allveh=vs.viewallvehicles();
        
        m.addAttribute("allveh", allveh);
        m.addAttribute("routeDictionaryJson", routeDictionaryJson);
        m.addAttribute("routeDictionary", routeDictionary);
        return "addbookcab";
    }
	
	
	@PostMapping("/addbookingcab")
	public String bookingcab(@ModelAttribute("book") bookcab bc,Model m) {

		String res=bs.addbookcab(bc);
		/*if(res.equalsIgnoreCase("success"))
			System.out.println("booking added");
		else
			System.out.println("booking not added");*/
		return "redirect:/allbooking";
	}
	
	@GetMapping("/allbooking")
	public String allbookingcab(Model m) {
		
		List<bookcab> allbookedcab=bs.viewall();
		m.addAttribute("allbookedcabs", allbookedcab);
		
		return "allbookcab";
	}
	
	@PostMapping("/delbooking")
	public String delete(@RequestParam("bookingid") int id,Model m) {
		
		bs.delete(id);
		return "redirect:/allbooking";
	}
	
}
