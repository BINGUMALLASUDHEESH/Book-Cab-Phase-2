package com.Phase3.bean;


import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name="vehicles")
public class vehicles {

	@Id
	@GeneratedValue
	private int id;
	  
	@Column(name="vname")
	private String vehicalname;
	
	
	private String vehicleno;
	
	private int seats;
	private String phone;
	
	@OneToMany(mappedBy="vehicle",cascade=CascadeType.ALL)
	private List<bookcab> book;

	
	public int getId() {
		return id;
	}
	public List<bookcab> getBook() {
		return book;
	}
	public void setBook(List<bookcab> book) {
		this.book = book;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getVehicalname() {
		return vehicalname;
	}
	public void setVehicalname(String vehicalname) {
		this.vehicalname = vehicalname;
	}
	public String getVehicleno() {
		return vehicleno;
	}
	public void setVehicleno(String vehicleno) {
		this.vehicleno = vehicleno;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
