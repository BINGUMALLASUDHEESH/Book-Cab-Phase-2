package com.Phase3.bean;



import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;



@Entity
@Table(name="bookcabdet")
public class bookcab {

    @Id
    @GeneratedValue
    private int bookID;

    private String date;
    private String fromLocation;
    private String toLocation;
    
  
    private String customerName;
    private String phone;
    
    @ManyToOne
    @JoinColumn(name = "vehicleid")
    private vehicles vehicle;
    
    
    
    public vehicles getVehicle() {
		return vehicle;
	}
	public void setVehicle(vehicles vehicle) {
		this.vehicle = vehicle;
	}
    
    
	public int getBookID() {
		return bookID;  
	}
	public void setBookID(int bookID) {
		this.bookID = bookID;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getFromLocation() {
		return fromLocation;
	}
	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}
	public String getToLocation() {
		return toLocation;
	}
	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
