package com.Phase3.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Phase3.bean.bookcab;

public interface bookrepo extends JpaRepository<bookcab, Integer> {

}
