package com.Phase3.service;

import java.util.List;

import com.Phase3.bean.bookcab;

public interface bookcabservice {

	public String addbookcab(bookcab bc);
	public List<bookcab> viewall();
	public void delete(int bid);
}
