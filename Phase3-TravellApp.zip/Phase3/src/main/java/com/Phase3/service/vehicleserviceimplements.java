package com.Phase3.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Phase3.bean.vehicles;
import com.Phase3.repository.vehiclerepo;


@Service
public class vehicleserviceimplements implements vehicleservice {

	
	@Autowired
	vehiclerepo vr;
	
	
	@Override
	public String addvehicle(vehicles veh) {
		
		vehicles res=vr.save(veh);
		
		if(res!=null)
			return "success";
		return null;
	}

	@Override
	public List<vehicles> viewallvehicles() {
		
		return vr.findAll();
	}

	@Override
	public void deletevehicle(int id) {
		
		vr.deleteById(id);
	}

	@Override
	public vehicles findbyid(int id) {
		
		Optional<vehicles> veh=vr.findById(id);
		
		if(veh.isPresent()) 
			return veh.get();
		return null;
	}

	@Override
	public String update(vehicles veh) {
		
		vehicles vel=new vehicles();
		
		vel.setId(veh.getId());
		vel.setVehicalname(veh.getVehicalname());
		vel.setVehicleno(veh.getVehicleno());
		vel.setPhone(veh.getPhone());
		vel.setSeats(veh.getSeats());
		
		vehicles res=vr.saveAndFlush(vel);
		
		if(res!=null)
			return "success";
		
		return null;
	}

}
