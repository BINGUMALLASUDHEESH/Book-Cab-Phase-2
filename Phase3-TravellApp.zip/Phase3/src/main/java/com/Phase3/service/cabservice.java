package com.Phase3.service;

import java.util.List;
import java.util.Map;

import com.Phase3.bean.cabfares;


public interface cabservice {

	public String addcab(cabfares cab);
	public List<cabfares> viewallcabs();
	public void deletecab(int id);
	public cabfares findbyid(int id); 
	public String update(cabfares cb);
	public Map<String, List<String>> createroutedictionary();
}
