package com.Phase3.service;

import java.util.List;


import com.Phase3.bean.vehicles;

public interface vehicleservice {

	
	public String addvehicle(vehicles veh);
	public List<vehicles> viewallvehicles();
	public void deletevehicle(int id);
	public vehicles findbyid(int id); 
	public String update(vehicles veh);
	
}
