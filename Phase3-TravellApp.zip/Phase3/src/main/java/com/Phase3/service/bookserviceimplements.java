package com.Phase3.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Phase3.bean.bookcab;
import com.Phase3.repository.bookrepo;

@Service
public class bookserviceimplements implements bookcabservice {
	
	@Autowired
	bookrepo br;

	@Override
	public String addbookcab(bookcab bc) {
		bookcab res=br.save(bc);
		if(res!=null)
			return "success";
		return null;
	}
	
	
	public List<bookcab> viewall() {
		
		return br.findAll();
	}


	@Override
	public void delete(int bid) {
		
		br.deleteById(bid);
		
	}

}
