package com.Phase3.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.Phase3.bean.cabfares;
import com.Phase3.repository.cabrepo;


@Service
public class cabserviceimplements implements cabservice {

	@Autowired
	cabrepo cr;
	
	
	
	
	@Override
	public String addcab(cabfares cab) {
		cabfares cabdet=cr.save(cab);
		if(cabdet!=null) {
			return "sucess";
		}
		return "error";
	}

	@Override
	public List<cabfares> viewallcabs() {
		
		return cr.findAll();
	}

	@Override
	public void deletecab(int id) {
		
		cr.deleteById(id);
		
	}

	@Override
	public cabfares findbyid(int id) {
		
		Optional<cabfares> cab=cr.findById(id);
		if(cab.isPresent())
			return cab.get();
		
		return null;
	}

	@Override
	public String update(cabfares cb) {
		
		
		cabfares cs=new cabfares();
		cs.setId(cb.getId());
		cs.setFrom_location(cb.getFrom_location());
		cs.setTo_location(cb.getTo_location());
		cs.setPrice(cb.getPrice());
		
		cabfares res=cr.saveAndFlush(cs);
		
		if(res!=null) {
			return "success";
		}
		return "Error";
	}
	
	
	public Map<String, List<String>> createroutedictionary() {
		
		
		Map<String, List<String>> routeDictionary = new HashMap<>();
		
		
        List<cabfares> routes = cr.findAll();

        for (cabfares route : routes) {
            String from = route.getFrom_location();
            String to = route.getTo_location();

            if (routeDictionary.containsKey(from)) {
                routeDictionary.get(from).add(to);
            } else {
                List<String> destinations = new ArrayList<>();
                destinations.add(to);
                routeDictionary.put(from, destinations);
            }
        }

        return routeDictionary;
		
	}

}
