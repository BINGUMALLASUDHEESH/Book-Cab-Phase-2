package com.Phase3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Phase3Application {

	public static void main(String[] args) {
		SpringApplication.run(Phase3Application.class, args);
		
		System.out.println("Phase 3 Project Started....!");
	}

}
